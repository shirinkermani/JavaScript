function main() {
    var no1 = 23;
    var no2 = 89;
    var no3 = 6;
    var ret = 0;
    ret = Maximum(no1, no2, no3);
    console.log("The Maximum Number is: " + ret);
}
function Maximum(Value1, Value2, Value3) {
    if (Value1 > Value2 && Value1 > Value3) {
        return Value1;
    }
    else if (Value2 > Value1 && Value2 > Value3) {
        return Value2;
    }
    else {
        return Value3;
    }
}
main();
