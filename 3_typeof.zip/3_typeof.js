// typeof operator returns the data type of the operand
var no = 101;
console.log(typeof no);
var str = "Marvellous Infosystems";
console.log(typeof str);
var value;
console.log(typeof value);
