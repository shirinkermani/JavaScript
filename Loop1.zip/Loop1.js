//Loop:for,while,do-while
function Sequence() {
    console.log("Sequence");
    console.log("Hello");
    console.log("Hello");
    console.log("Hello");
    console.log("Hello");
    console.log("Hello");
}
function Iteration_For() {
    console.log("For Loop");
    var i = 0;
    for (i = 1; i <= 5; i++) {
        console.log("Hello");
    }
}
function Iteration_While() {
    console.log("While Loop");
    var i = 0;
    while (i <= 5) {
        console.log("Hello");
        i++;
    }
}
Sequence();
Iteration_For();
Iteration_While();
