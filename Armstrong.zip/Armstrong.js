// var no:153;
// var ret=0;
// ret = chkArmstrong(no)
// console.log("It is a armstrong number " +ret)
// function chkArmstrong(arm:number):number{
//     let d: string[];
//     let i: number;
//     for(let i = 0; i<d.length; i++) {
//         sum = sum + Math.pow(d[i], 3)
//      }
//      if(sum == c) {
//          console.log("armstrong")
//      }
//      else {
//          console.log("not a armstrong")
//      }
//     return no;
// }
//     console.log(chkArmstrong);
// function three_digit_armstrong_number() 
// {
//  for (var i = 1; i < 10; ++i) 
//  {
//    for (var j = 0; j < 10; ++j) 
//      {
//         for (var k = 0; k < 10; ++k)
//         {
//           var pow = (Math.pow(i,3) + Math.pow(j,3) + Math.pow(k,3));
//           var plus = (i * 100 + j * 10 +  k);
//           if (pow == plus) 
//            {     
//              console.log(pow);
//             }
//          }
//        }
//     }
//   }
// three_digit_armstrong_number();
function armstrong(n) {
    var number = new String(n);
    n = number.length;
    var output = 0;
    for (var _i = 0, n_1 = n; _i < n_1.length; _i++) {
        var i = n_1[_i];
        output = output + Math.pow(parseInt(i), n);
    }
    if (output == parseInt(n))
        return ("True" + "<br>");
    else
        return ("False" + "<br>");
}
console.log(armstrong(153));
