//Object Oriented programming(OOP)
var Arithmetic = /** @class */ (function () {
    function Arithmetic(a, b) {
        //console.log("Inside Constructor")
        this.No1 = a;
        this.No2 = b;
    }
    Arithmetic.prototype.Addition = function () {
        var Ans = 0; //local var inside func
        Ans = this.No1 + this.No2;
        return Ans;
    };
    Arithmetic.prototype.Substraction = function () {
        var Ans = 0; //local var inside func
        Ans = this.No1 - this.No2;
        return Ans;
    };
    return Arithmetic;
}());
var obj1 = new Arithmetic(10, 11); //object created, this will call constructor 2 times, the no of objs created=no of calls to the const
var obj2 = new Arithmetic(20, 21);
var Ret = 0;
Ret = obj1.Addition();
console.log("Addition is : " + Ret);
Ret = obj1.Substraction();
console.log("Substraction is : " + Ret);
