var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Circle = /** @class */ (function () {
    function Circle(a) {
        this.Radius = a;
        this.PI = 3.14;
    }
    Circle.prototype.Area = function () {
        var Ans = 0;
        Ans = this.PI * this.Radius * this.Radius;
        return Ans;
    };
    return Circle;
}());
var obj1 = new Circle(10);
var obj2 = new Circle(20);
var Ret = 0;
Ret = obj1.Area();
console.log("Area is : " + Ret);
Ret = obj2.Area();
console.log("Area is : " + Ret);
var CircleX = /** @class */ (function (_super) {
    __extends(CircleX, _super);
    function CircleX(a) {
        var _this = _super.call(this, a) || this;
        _this.PI = 3.14;
        return _this;
    }
    CircleX.prototype.Circumference = function () {
        _super.prototype.Area.call(this);
        var Ans = 0;
        Ans = 2 * this.PI * this.Radius;
        return Ans;
    };
    return CircleX;
}(Circle));
var obj3 = new CircleX(10);
var obj4 = new CircleX(20);
var Ret = 0;
Ret = obj3.Circumference();
console.log("Circumference is : " + Ret);
Ret = obj4.Circumference();
console.log("Circumference is : " + Ret);
