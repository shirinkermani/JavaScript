//Number of required arguments are 3
function Demo(no1, no2, no3) {
    console.log("Inside Demo");
}
Demo(10, 20, 30);
