// Defination of add function
function add(no1, no2) {
    var ans;
    ans = no1 + no2;
    return ans;
}
var iret;
iret = add(10, 1);
console.log("Addition is :" + iret);
