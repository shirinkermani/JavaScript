function main() {
    var p = 12;
    var bret;
    bret = chkPrime(p);
    if (bret == false) {
        console.log("It is not a prime number");
    }
    else {
        console.log("It is a prime number");
    }
}
function chkPrime(Value1) {
    var i = 0;
    var bret;
    for (i = 2; i < Value1; i++) {
        if (Value1 % i == 0) {
            bret = false;
            return bret;
        }
    }
}
main();
