function main() {
    var Rad = 5;
    var PI = 3.14;
    var ret = 0;
    ret = Area(Rad, PI);
    console.log("The Area Of Circle is: " + ret);
}
function Area(Value1, Value2) {
    var Area = Value1 * Value1 * Value2;
    return Area;
}
main();
