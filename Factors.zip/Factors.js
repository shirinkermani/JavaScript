function main() {
    var fact = 20;
    var ret = 0;
    ret = DisplayFactors(fact);
}
function DisplayFactors(Value1) {
    var i = 1;
    for (i = 1; i < Value1; i++) {
        if (Value1 % i == 0) {
            console.log(i);
        }
    }
    return i;
}
main();
