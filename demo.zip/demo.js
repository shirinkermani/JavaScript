var no = 11;
var str = "Hello World";
console.log(str);
console.log(no);
