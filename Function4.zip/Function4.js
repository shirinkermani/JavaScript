function main() {
    var no = 12; //3
    var bret; //4
    bret = CheckEven(no); //5 //CheckEven(12) //9
    if (bret == true) //10
     {
        console.log("It is even number"); //11
    }
    else {
        console.log("it is odd number");
    }
}
function CheckEven(Value) {
    if ((Value % 2) == 0) //7
     {
        return true; //8
    }
    else {
        return false;
    }
}
main(); //1
