function main() {
    var F = 21;
    var ret = 0;
    ret = Fibonacci(F);
}
function Fibonacci(Value1) {
    var num1 = 0;
    var num2 = 1;
    var i = 0;
    while (i < Value1) {
        i = num1 + num2;
        console.log(i);
        num1 = num2;
        num2 = i;
    }
    return i;
}
main();
