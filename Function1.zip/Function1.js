function fun() {
    console.log("Inside Fun");
}
fun(); //func call
function gun(no) {
    console.log("Inside gun : " + no);
}
gun(11);
function sun(no) {
    var i = no;
    i++;
    return i;
}
var ret = 0;
var a = 10;
ret = sun(a);
console.log("The return value is: " + ret);
