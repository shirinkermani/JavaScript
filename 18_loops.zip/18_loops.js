var no = 5;
var i;
console.log("for loop deomnstration :");
for (i = 1; i <= no; i++) {
    console.log(i);
}
console.log("while loop deomnstration :");
i = 1;
while (i <= no) {
    console.log(i);
    i++;
}
console.log("do-while loop deomnstration :");
i = 1;
do {
    console.log(i);
    i++;
} while (i <= no);
