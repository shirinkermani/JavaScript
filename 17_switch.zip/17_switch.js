var Div = "B";
switch (Div) {
    case "A":
        {
            console.log("Timing : 7 AM to 11 AM");
            break;
        }
    case "B":
        {
            console.log("Timing : 9 AM to 12 AM");
            break;
        }
    case "C":
        {
            console.log("Timing : 1 PM to 6 PM");
            break;
        }
    default:
        {
            console.log("Invalid Division");
            break;
        }
}
