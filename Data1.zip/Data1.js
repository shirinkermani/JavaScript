var a1 = 11; //works in js+ts
var a2 = 11; // works in ts
//number->int,float,double,short,long
console.log(a1);
console.log(a2);
