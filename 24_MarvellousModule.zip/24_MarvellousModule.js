"use strict";
exports.__esModule = true;
var _23_MarvellousModule_1 = require("./23_MarvellousModule");
var empObj = new _23_MarvellousModule_1.Employee("Piyush", 11);
empObj.displayEmployee();
