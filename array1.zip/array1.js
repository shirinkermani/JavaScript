//int Arr[5]={10,20,30,40,50};
//Arr is one dimensional array which contains 5 elements each element is of type number
var Arr = [10, 20, 30, 40, 50];
console.log("Length of array is: " + Arr.length);
console.log("First element is: " + Arr[0]);
console.log("Second element is: " + Arr[1]);
console.log("Elements from array are: ");
var i = 0;
for (i = 0; i < Arr.length; i++) {
    console.log(Arr[i]);
}
